package com.nl.Printer;

import java.awt.print.PrinterException;

public class PrintingMain {

    public static void printAll() throws PrinterException {
        TextOverlay.create("Água");
    }

}
