interface IItens {
  id: number;
  produto: number;
  preco: number;
  quantidade: string;
  total: string;
}
